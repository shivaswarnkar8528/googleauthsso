// const googleOAuth20Service = require('../src/index.js');
// const passport = require('passport');

// describe('googleOAuth20Service', () => {
//   it('should authenticate a user', async () => {
//     const passportMock = jest.fn();
//     const config = {
//       GOOGLE_CLIENT_ID: 'client-id',
//       GOOGLE_CLIENT_SECRET: 'client-secret',
//       GOOGLE_CALLBACK_URL: 'callback-url'
//     };

//     await googleOAuth20Service(passportMock, config);

//     expect(passportMock.use).toHaveBeenCalledTimes(1);
//   });
// });