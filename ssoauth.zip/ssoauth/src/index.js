const GoogleStrategy = require("passport-google-oauth20").Strategy;
const session = require("express-session");
const googleOAuth20Service = (authArgs) => {
  // const oAuthArgs={
  //     serverInstance:app,
  //     passport:passport,
  //     config:config,
  //     redirection:{success:'/dashboard',failure:'/'},
  //     dboperation:null
  //   }
  const { serverInstance, passport, config } = { ...authArgs };
  const redirection = authArgs?.redirection || {
    success: "/home",
    failure: "/login",
  };
  const dboperation = authArgs?.dboperation;
  if (
    !config.GOOGLE_CLIENT_ID ||
    !config.GOOGLE_CLIENT_SECRET ||
    !config.GOOGLE_CALLBACK_URL ||
    !config.SESSION_SECRET
  ) {
    throw new Error(
      "Please provide GOOGLE_CLIENT_ID, GOOGLE_CLIENT_SECRET and GOOGLE_CALLBACK_URL and SESSION_SECRET in .env file"
    );
  }
  if (!serverInstance || !passport) {
    throw new Error("Please provide serverInstance and passport in authArgs");
  }

  serverInstance.use(
    session({
      secret: config.SESSION_SECRET,
      resave: false,
      saveUninitialized: false,
    })
  );

  // Initialize Passport
  serverInstance.use(passport.initialize());
  serverInstance.use(passport.session());
  passport.use(
    new GoogleStrategy(
      {
        clientID: config.GOOGLE_CLIENT_ID,
        clientSecret: config.GOOGLE_CLIENT_SECRET,
        callbackURL: config.GOOGLE_CALLBACK_URL,
      },
      async (accessToken, refreshToken, profile, done) => {
        try {
          // Find or create a user in the database
          let user = dboperation ? await dboperation() : null;
          profile.db_user = user;
          return done(null, profile);
        } catch (error) {
          return done(error, null);
        }
      }
    )
  );
  passport.serializeUser((user, done) => {
    done(null, user);
  });

  passport.deserializeUser((user, done) => {
    done(null, user);
  });

  serverInstance.get(
    "/auth/google",
    passport.authenticate("google", { scope: ["profile", "email"] })
  );

  serverInstance.get(
    "/auth/google/callback",
    passport.authenticate("google", { failureRedirect: redirection?.failure }),
    function (req, res) {
      // Successful authentication, redirect home.
      res.redirect(redirection?.success);
    }
  );
};

module.exports = googleOAuth20Service;
